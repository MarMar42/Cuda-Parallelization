To compile all code type in the terminal "make all"

To compile Transpose: make Trans
To compile Vector Addition: make VecAdd
To compile Matric Multiplication: make MatMul

To remove all compiled files: make clean